---
files:
  - "[[TA7.4]]"
---
## Reach good chemical and quantitative status in groundwaters and surfacewaters

->[[TA7_Towards a zero-pollution ambition for a toxic free environment]]

Tags: nan