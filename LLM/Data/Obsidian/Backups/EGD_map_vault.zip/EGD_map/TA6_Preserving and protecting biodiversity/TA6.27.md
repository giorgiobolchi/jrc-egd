---
files:
  - "[[TA6.17]]"
---
## Optimise exploitation patterns to provide protection for juveniles and spawning aggregations of marine biological resources

->[[TA6_Preserving and protecting biodiversity]]

Tags: nan