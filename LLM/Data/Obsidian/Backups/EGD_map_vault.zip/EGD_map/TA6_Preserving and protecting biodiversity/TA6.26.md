---
files:
  - "[[TA6.17]]"
  - "[[TA6.18]]"
---
## Ensure that incidental catches of sensitive marine species, including those listed under Directives 92/43/EEC and 2009/147/EC, that are a result of fishing, are minimised and where possible eliminated so that they do not represent a threat to the conservation status of these species

->[[TA6_Preserving and protecting biodiversity]]

Tags: #grey