---
files:
  - "[[TA6.54]]"
  - "[[TA6.56]]"
  - "[[TA6.59]]"
---
## Developing skills and empowering people for sustainable forest-based bioeconomy

->[[TA6_Preserving and protecting biodiversity]]

Tags: nan