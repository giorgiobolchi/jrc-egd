---
links:
  - "[[TA4.39]]"
---
## High-speed rail traffic will double compared to 2015, by 2030. It will triple by 2050.

thematic area: #TA4_Sustainable_and_smart_mobility

Tags: #orange