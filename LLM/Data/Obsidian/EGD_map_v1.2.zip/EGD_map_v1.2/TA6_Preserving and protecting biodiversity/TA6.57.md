---
links:
  - "[[TA6.54]]"
  - "[[TA6.56]]"
  - "[[TA6.59]]"
---
## Developing skills and empowering people for sustainable forest-based bioeconomy

thematic area: #TA6_Preserving_and_protecting_biodiversity

Tags: nan